import { createClient } from '@supabase/supabase-js';

const SUPABASE_URL = 'https://vhsartrjyobkawkayloy.supabase.co';
const SUPABASE_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InZoc2FydHJqeW9ia2F3a2F5bG95Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3MzE4NzY5MjAsImV4cCI6MjA0NzQ1MjkyMH0.6tr0A9U3bB93foDvKgMyGdFn3mJDwuW_sSAwapu6xik';


export const supabase = createClient(SUPABASE_URL, SUPABASE_KEY);