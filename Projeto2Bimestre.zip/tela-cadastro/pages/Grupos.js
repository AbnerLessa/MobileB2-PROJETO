import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity, ActivityIndicator, Alert, StyleSheet, ImageBackground } from 'react-native';
import { fetchGroupsFromDatabase } from '../dados';

export default function Groups({ navigation }) {
  const [groups, setGroups] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchGroups = async () => {
    try {
      const data = await fetchGroupsFromDatabase();
      setGroups(data);
    } catch (err) {
      console.error('Erro ao buscar grupos:', err.message);
      Alert.alert('Erro', 'Não foi possível carregar os grupos.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchGroups();
  }, []);

  if (loading) {
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
        <ActivityIndicator size="large" color="#0000ff" />
        <Text>Carregando grupos...</Text>
      </View>
    );
  }

  return (
    <ImageBackground
      source={require('../assets/imagem1.avif')} 
      style={styles.background}
    >
      <View style={styles.container}>
        <Text style={styles.header}>Grupos Inova Week</Text>
        {groups.map((group) => (
          <TouchableOpacity
            key={group.id}
            onPress={() => navigation.navigate('GroupDetails', { id: group.id })}
            style={styles.groupItem}
          >
            <Text style={styles.groupName}>{group.nome}</Text>
            <Text style={styles.groupDescription}>{group.descricao}</Text>
          </TouchableOpacity>
        ))}
      </View>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  background: {
    flex: 1,
    justifyContent: 'center',
    padding: 20,
  },
  container: {
    backgroundColor: 'rgba(255, 255, 255, 0.7)',  
    borderRadius: 10,
    padding: 20,
  },
  header: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
  },
  groupItem: {
    padding: 15,
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 8,
    marginBottom: 10,
  },
  groupName: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  groupDescription: {
    marginTop: 5,
    color: '#555',
  },
});
