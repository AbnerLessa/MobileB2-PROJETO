import React, { useState } from 'react';
import { View, TextInput, Button, Text, Alert, StyleSheet, ImageBackground } from 'react-native';
import { supabase } from '../lib/supabase';

export default function ForgotPassword({ navigation }) {
  const [email, setEmail] = useState('');
  const [isSent, setIsSent] = useState(false);

  const handleSendLink = async () => {
    if (!email) {
      alert('Por favor, insira seu e-mail.');
      return;
    }

    try {
      const { error } = await supabase.auth.api.resetPasswordForEmail(email);
      if (error) {
        console.error('Erro ao enviar link de recuperação:', error.message);
        Alert.alert('Erro', 'Não foi possível enviar o link de recuperação.');
      } else {
        setIsSent(true);
        Alert.alert('Sucesso', 'Link de recuperação enviado para o seu e-mail!');
      }
    } catch (err) {
      console.error('Erro inesperado:', err.message);
      Alert.alert('Erro inesperado', 'Tente novamente mais tarde.');
    }
  };

  return (
    <ImageBackground
      source={require('../assets/imagem1.avif')}  // Caminho para a imagem de fundo
      style={styles.background}
    >
      <View style={styles.container}>
        <TextInput
          placeholder="Email"
          value={email}
          onChangeText={setEmail}
          style={styles.textInput}
        />
        <Button title="Enviar Link de Recuperação" onPress={handleSendLink} />
        {isSent && <Text style={styles.successMessage}>Link enviado com sucesso!</Text>}
        <Text
          style={styles.link}
          onPress={() => navigation.navigate('Login')}
        >
          Voltar para o Login
        </Text>
      </View>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  background: {
    flex: 1,
    justifyContent: 'center',
    padding: 20,
  },
  container: {
    backgroundColor: 'rgba(255, 255, 255, 0.7)',  // Para facilitar a leitura
    borderRadius: 10,
    padding: 20,
  },
  textInput: {
    borderBottomWidth: 1,
    marginBottom: 20,
    padding: 10,
  },
  successMessage: {
    marginTop: 10,
    color: 'green',
  },
  link: {
    marginTop: 20,
    color: 'blue',
    textDecorationLine: 'underline',
  },
});
