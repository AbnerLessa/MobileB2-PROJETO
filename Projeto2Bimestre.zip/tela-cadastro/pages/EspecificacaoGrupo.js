import React, { useState, useEffect } from 'react';
import { View, Text, Alert, StyleSheet, ImageBackground } from 'react-native';
import { fetchGroupDetailsById } from '../dados';

export default function GroupDetails({ route, navigation }) {
  const { id } = route.params;
  const [group, setGroup] = useState(null);

  useEffect(() => {
    const fetchGroup = async () => {
      try {
        const data = await fetchGroupDetailsById(id);
        setGroup(data);
      } catch (err) {
        console.error('Erro ao buscar grupo:', err.message);
        Alert.alert('Erro', 'Não foi possível carregar os detalhes do grupo.');
      }
    };

    fetchGroup();
  }, [id]);

  if (!group) return <Text>Carregando...</Text>;

  return (
    <ImageBackground
      source={require('../assets/imagem1.avif')}  
      style={styles.background}
    >
      <View style={styles.container}>
        <Text style={styles.groupName}>{group.nome}</Text>
        <Text style={styles.groupDescription}>Descrição: {group.descricao}</Text>
        <Text style={styles.groupDate}>
          Data de Criação: {new Date(group.data_criacao).toLocaleDateString()}
        </Text>
        <Text style={styles.membersTitle}>Integrantes:</Text>
        {group.integrantes.map((member) => (
          <Text key={member.id} style={styles.member}>
            {member.nome} - {member.curso}
          </Text>
        ))}
        <Text
          style={styles.backToGroups}
          onPress={() => navigation.navigate('Groups')}
        >
          Voltar para a lista de grupos
        </Text>
      </View>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  background: {
    flex: 1,
    justifyContent: 'center',
    padding: 20,
  },
  container: {
    backgroundColor: 'rgba(255, 255, 255, 0.7)',  
    borderRadius: 10,
    padding: 20,
  },
  groupName: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  groupDescription: {
    fontSize: 16,
    marginBottom: 10,
  },
  groupDate: {
    fontSize: 16,
    marginBottom: 10,
  },
  membersTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  member: {
    fontSize: 16,
  },
  backToGroups: {
    marginTop: 20,
    color: 'blue',
  },
});
